# Nine Coding Challenge by Joshua Huynh

The purpose of this website is to return JSON data filtered from a POST request.
When a POST request is sent to the website, refresh the page to see the results
update on screen.
